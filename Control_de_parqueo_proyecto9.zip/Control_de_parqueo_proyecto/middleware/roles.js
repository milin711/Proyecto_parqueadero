const { error } = require("../utils");

// Uso: router.post("/", roles("ADMIN"), handler)
module.exports = (...permitidos) => (req, res, next) =>
  permitidos.includes(req.user?.rol) ? next() : error(res, 403, "No tienes permiso para esta acción");
