const jwt = require("jsonwebtoken");
const { SECRET } = require("../config");
const { error } = require("../utils");

module.exports = function auth(req, res, next) {
  const h = req.headers.authorization || "";
  const token = h.startsWith("Bearer ") ? h.slice(7) : null;
  if (!token) return error(res, 401, "Token requerido");
  try {
    req.user = jwt.verify(token, SECRET);
    next();
  } catch {
    return error(res, 401, "Token inválido o expirado");
  }
};
