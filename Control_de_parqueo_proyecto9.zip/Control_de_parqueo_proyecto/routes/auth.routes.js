const express = require("express");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const db = require("../db");
const { SECRET, EXPIRA_SEG } = require("../config");
const { error } = require("../utils");

const router = express.Router();

const sesion = (u) => ({
  token: jwt.sign({ id: u.id, rol: u.rol }, SECRET, { expiresIn: EXPIRA_SEG }),
  expiraEn: EXPIRA_SEG,
  usuario: { id: u.id, nombre: u.nombre, rol: u.rol },
});

// POST /api/v1/auth/login
router.post("/login", (req, res) => {
  const { usuario, password } = req.body || {};
  if (!usuario || !password) return error(res, 400, "usuario y password son obligatorios");

  const u = db.prepare("SELECT * FROM usuario WHERE usuario = ? COLLATE NOCASE").get(String(usuario).trim());
  if (!u || !bcrypt.compareSync(password, u.password_hash))
    return error(res, 401, "Credenciales inválidas");
  res.json(sesion(u));
});

// POST /api/v1/auth/registro  ->  crea una cuenta de persona (rol CLIENTE) y abre sesión
router.post("/registro", (req, res) => {
  const nombre = String(req.body?.nombre || "").trim();
  const usuario = String(req.body?.usuario || "").trim().toLowerCase();
  const password = String(req.body?.password || "");

  if (nombre.length < 2 || nombre.length > 60) return error(res, 400, "Escribe tu nombre (2 a 60 letras)");
  if (!/^[a-z0-9_.]{3,20}$/.test(usuario))
    return error(res, 400, "El usuario debe tener de 3 a 20 caracteres: letras, números, punto o guion bajo");
  if (password.length < 6) return error(res, 400, "La contraseña debe tener al menos 6 caracteres");
  if (db.prepare("SELECT id FROM usuario WHERE usuario = ?").get(usuario))
    return error(res, 409, "Ese usuario ya existe, elige otro");

  const info = db.prepare("INSERT INTO usuario (nombre, usuario, password_hash, rol) VALUES (?,?,?,'CLIENTE')")
    .run(nombre, usuario, bcrypt.hashSync(password, 10));
  res.status(201).json({ mensaje: "Cuenta creada. Ya puedes iniciar sesión.", usuario: { id: info.lastInsertRowid, nombre, usuario } });
});

module.exports = router;
